# [FiveM] Walkable Hands Up

A little script to be able walk with hands up.

Just press X to put your hands up and second press to get off it
